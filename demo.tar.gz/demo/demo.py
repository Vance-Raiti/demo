from db.scrape import scrape
from db.table import main as get_ddg
from collections import deque
from preprocess import feature_functions
import torch

from model import MultiLayerPerceptron

class queue:
    def __init__(self):
        self.q = deque()

    def put(self,x):
        self.q.append(x)

    def get(self):
        return self.q.popleft()

    def qsize(self):
        return len(self.q)

tensorfy = lambda x: torch.tensor(x,dtype=torch.float)

qin, qout = queue(), queue()

net = None

while True:
    try:
        qin.put(input())
    except EOFError:
        break
    scrape(qin,qout)
    url, html, page_rank, age = qout.get()
    ddg = get_ddg(url)

    features = []
    try: 
        for fn in feature_functions:
            features += fn(html,url,ddg,page_rank)
    except Exception:
        print("website not accessible :(")
    x = tensorfy(features)

    if net is None:
        net = MultiLayerPerceptron(in_features=x.shape[0])
        net.load_state_dict(torch.load('model.pt'))
    y_hat = net(x).item()
    if y_hat > 0.5:
        msg = "Looks like a phishing website to me"
    else:
        msg = "Looks like a legitimate website to me"
    print(f"{msg} ({y_hat})")
